#include "MT.h"
#include <iomanip>
#include <vector>
#include <string>
#include <cstring>

#include <algorithm>
#include <math.h>
#include <cmath>

#include <time.h>

#include <cassert>
#include <limits>

#include <stdlib.h>
#include <cstdlib>
#include <ctype.h>
#include <unistd.h>
#include <stdio.h>

#include <fstream>
#include <sstream>
#include <iostream>
#include <map>
#include <sys/stat.h>

#define VER 1.1
#define TRUE 1
#define FALSE 0
#define ZERO 1.e-12
#define STOP_FILE "stop_jnmf.txt"

using namespace std;

class Parameter{
 public:
  Parameter(){
    howmany_runs = 10;  //default value
    howmany_loop = 100; //default value
    ranks           = 3;    //default value
    Cons_Thres  = 0.7; //default value
    write_gene   = 0;    //default no-output

    *(gefile+0) = '\0'; 
    *(ctfile+0) = '\0';
  }
  
  int howmany_runs;
  int howmany_loop;
  int ranks;
  bool write_gene;
  double Cons_Thres;

  char gefile[256];   char ctfile[256];
  
  ~Parameter(){
  }
};

class MatrixFactor{
 public:
  MatrixFactor(){
    h1 = NULL;       h2 = NULL;     wh1 = NULL;    wh2 = NULL;     w    = NULL;     diff   = 0;
  }
  double* h1;     double* h2;   double* w;   double* wh1;   double* wh2;  double diff;
  
  ~MatrixFactor(){
    if(h1 != NULL){ delete h1; }
    if(h2 != NULL){ delete h2; }
    if(w != NULL){ delete w; }
    if(wh1 != NULL){ delete wh1; }
    if(wh2 != NULL){ delete wh2; }
  }

};

void matrix_print_module(const std::vector<std::pair<int, double>> Fv, double *M, int row, int col,
			 string *TYPE,
			 std::string *file_name,
			 double *W, int mode){
  int i,j, this_module;

  std::ofstream file( file_name->c_str(), ios_base::out|ios_base::app);

  for(i=0; i<row; i++){

    //ID consensus
    std::vector<std::pair<int, double>> MOD;
    //ID weight
    std::vector<double> MOD_W(col);
    
    for(j=0; j < col;  j++){           //search value 1 from each column
      MOD_W[j] = 0.0;

      //this feature ID j is sorted ID. its original ID is Fv[j].first
      if(  *(M + (i * col + j) ) > 0 ){ //== 1){
	
	MOD.push_back(   std::make_pair( j+1, *(M + (i * col + j) ) ));

	if(mode == 1){
	  MOD_W[j] =  *(W + ( i*col + Fv[j].first) ); //col <- MOD.size(). DO NOT USE "j+1" as an index
	}else{
	  MOD_W[j] =  *(W + ( Fv[j].first * row + i) ); //row. Just serial 
	}


      }
    }
    
    if( MOD.size() > 0){

      file << *TYPE << "\t";
      file << i + 1 << "\t"; // ID
      
      this_module = 0;
      for(j = 0; j<MOD.size(); j++){
	if(MOD[j].second > 0){
	  if( this_module ){ 
	    file << ",";
	  }
	  file << MOD[j].first; // << "\t" << MOD[j].second << "\t" << MOD_F[j];
	  this_module++;
	}
      }
      file << "\t";

      this_module = 0;
      for(j = 0; j<MOD.size(); j++){
	if(MOD[j].second > 0){
	  if( this_module ){ 
	    file << ",";
	  }
	  file << std::fixed << std::setprecision(2) << MOD[j].second;
	  this_module++;
	}
      }
      file << "\t";

      this_module = 0;
      for(j = 0; j<MOD.size(); j++){
	if(MOD[j].second > 0){
	  if( this_module ){ 
	    file << ",";
	  }
	  file << std::fixed << std::setprecision(4) << MOD_W[ MOD[j].first - 1 ];
	  //file << std::fixed << MOD_W[ MOD[j].first - 1 ];
	}
      }
      file << endl;
    }
  }

  file.close();

}


void factorize(int row,  double *v1, int col1,  int ranks, unsigned int count, MatrixFactor *mf);

void joint_factorize(int row,
		     double *v1, int col1,
		     double *v2, int col2,
		     int ranks, unsigned int count,
		     MatrixFactor *mf,
		     double *ConsCell, double *ConsGE, double *ConsCT
		     );

void matrix_add(double *c, const double *a, const double *b, const int n, const int m);
void matrix_subtract_abs_bool(double *c, const double *a, const double *b, const int n, const int m, int mode);
double Uniform( void );

void matrix_oneNorm_col(double *a, const int n, const int m);
void matrix_init(double *a, const int n, const int m);
void matrix_init_zero(double *a, const int n, const int m);
void matrix_copy(double *a, const double *b, const int n, const int m);
void matrix_print(const double *a, const int n, const int m);
void matrix_x(double *c, const double *a, const double *b, const int l, const int m, const int n);
void matrix_x(double *c, const double *a, const double *b, const int n, const int m);
void matrix_divide_scalar(double *c, const double *a, const double b, const int n, const int m);
void matrix_divide(double *c, const double *a, const double *b, const int l, const int m, const int n);
void matrix_divide(double *c, const double *a, const double *b, const int n, const int m);
void matrix_transpose(const double *a, double *b, const int n, const int m);
void matrix_left_transpose_x(double *c, const double *a, const double *b, const int l, const int m, const int n);
void matrix_right_transpose_x(double *c, const double *a, const double *b, const int l, const int m, const int n);
void matrix_tx_left(double *c, const double *a, const double *b, const int l, const int m, const int n);
void matrix_tx_right(double *c, const double *a, const double *b, const int l, const int m, const int n);


void consensus_maxCol(double* a, const double* b, int row, int col);
void consensus_maxRow(double* a, const double* b, int row, int col);
void Update_ConsM(double* Cons, double* M, int row, int col, int mode);

std::vector<std::string> FiletoMatrix(  std::string *file_name,   int *row, int *col);
int getParam(int argc, char* argv[], Parameter* param, int howmany);
void MatrixtoFile( std::string *file_name, double *m, int row, int col, std::string *message);


// n = row, m=col, c=result matrix, a,b = two matrices
void matrix_add(double *c, const double *a, const double *b, const int n, const int m){
  int i, j;

  for (i = 0; i <n; i++){ //row
    for (j = 0; j < m; j++){ //col
      *(c + i * m + j) = *(a + i * m + j) + *(b + i * m + j);
    }
  }
}

// n = row, m=col, c=result matrix, a,b = two matrices
// result matrix includes 1 or 0, mode controls a-b = 0 -> 0 or a-b = 0 -> 1, 
void matrix_subtract_abs_bool(double *c, const double *a, const double *b, const int n, const int m, int mode){
  int i, j;
  double v;

  for (i = 0; i <n; i++){ //row
    for (j = 0; j < m; j++){ //col
      
      v = abs( *(a + i * m + j) - *(b + i * m + j) );
      if(mode == 0){ //usual
	if(v > 0){	
	  *(c + i * m + j) = 1;
	}else{
	  *(c + i * m + j) = 0;
	}
      }else{ //opposite if value exists c matrix gets zero
	if(v > 0){	
	  *(c + i * m + j) = 0;
	}else{
	  *(c + i * m + j) = 1;
	}
      }
      
    } //col
  } //row


}


// n = row, m=col, sclar
double matrix_diff(const double *a, const double *b, const int n, const int m){
int i, j;
  double diff = 0.0;
  i=j = 0;
  
  for (i = 0; i < n; i++){
    for (j = 0; j < m; j++){
      //  sum [ (aij - bij)^2 ]
      diff += (double)pow( *(a + i * m + j) - *(b + i * m + j), 2);
    }
  }
  
  return diff;
}

// random number generator
double Uniform( void ){
  //printf("RAND_MAX=%d\n",RAND_MAX);
  //return ((double)rand()+1.0)/((double)RAND_MAX+2.0);

  return genrand_real3();
}


// a: target martrix, b: vector for maximum row for each column
void matrix_oneNorm_col(double *a, const int n, const int m){
  double total;
  int i, j;

  for (j = 0; j < m; j++){ //col

    total = 0.0;
    for (i = 0; i < n; i++){ //row
      total +=  *(a + (i * m + j));
    }
    if(total < ZERO){  total = 1e-6; }

    for (i = 0; i < n; i++){ //row
      *(a + (i * m + j)) /= total;
    }
  
  }

}



//n = row, m = col
void matrix_init(double *a, const int n, const int m){

  int i, j;
  for (i = 0; i < n; i++){ //row
    for (j = 0; j < m; j++){ //col
      *(a + (i * m + j)) = (double)Uniform();
    }
  }

  matrix_oneNorm_col(a, n, m);
}

//cstring header
void matrix_init_zero(double *a, const int n, const int m){
	memset(a, 0x00, n * m * sizeof(double));
}

// copy B -> A
void matrix_copy(double *a, const double *b, const int n, const int m){
	memcpy(a, b, n * m * sizeof(double));
}

// n = row, m = col
void matrix_print(const double *a, const int n, const int m){
  int i, j;
  /*
  if(trans){ //transpose
    for (i = 0; i < m; i++){
      for (j = 0; j < n; j++){
	printf("%3.4f ", *(a + (j * m + i)));
      }
      printf("\n");
    }

  }else{
  */
    for (i = 0; i < n; i++){ //row
      for (j = 0; j < m; j++){ //col
	printf("%3.4f ",  *(a + (i * m + j) ) );
      }
      printf("\n");
    }
    //}

  printf("\n");
}

//============================#
// Two functions, 
// matrix_x(c,a,b, l,m,n) -> for %*%
// matrix_x(c,a,b, n,m )  -> for *
//============================#

// c = result, a,b = two matrices, a %*% b
// a = l x m
// b = m x n
// c = l x n
void matrix_x(double *c, const double *a, const double *b, const int l, const int m, const int n){
  double t = 0;
  int i, j, k;
  i = j= k=0;

  for (i = 0; i < l; i++){
    for ( j = 0; j < n; j++){
      t = 0.0;
      for (k = 0; k < m; k++){
	t += *(a + (i * m + k)) * *(b + (k * n + j));
      }
      *(c + (i * n + j)) = t;
    }
  }

}

// c = retult, a,b = two matrices, a * b
// a = n x m
// b = n x m
// c = n x m
void matrix_x(double *c, const double *a, const double *b, const int n, const int m){
  int i, j;
  i = j= 0;

  for (i = 0; i < n; i++){ //row
    for (j = 0; j < m; j++){ //col
      *(c + (i * m + j)) = *(a + (i * m + j)) * *(b + (i * m + j));
    }
  }
}

void matrix_divide_scalar(double *c, const double *a, const double b, const int n, const int m){
  int i, j;

  for (i = 0; i < n; i++){
    for (j = 0; j < m; j++){
      *(c + (i * m + j) ) = *(a + (i * m + j))  / b;
    }
  }
  
}

// c = retult, a,b =two matrices
// a = l   x m
// b = m x n
// c = n  x l 
void matrix_divide(double *c, const double *a, const double *b, const int l, const int m, const int n){
  double t = 0;
  int i, j, k;
  i = j= k=0;

  for (i = 0; i < n; i++){ //col in B
    for (j = 0; j < l; j++){ //row in A
      t = 0.0;
      for (k = 0; k < m; k++){ //col in A, row in B
	t += *(a + (i * m + k))  / *(b + (k * n + j) );
      }
 
      if(std::isnan( t ) ){ t = 0.0; }
      *(c + (i * l + j) ) = t;

    }

  }

}

// c = result, a,b = two matrices
// a = n x m
// b = n x m
// c = n x m
void matrix_divide(double *c, const double *a, const double *b, const int n, const int m){
  int i, j;
  i = j= 0;
  
  for (i = 0; i < n; i++){ //row
    for (j = 0; j < m; j++){ //col
      *(c + (i * m + j)) = *(a + (i * m + j)) / *(b + (i * m + j));
      
      if( std::isnan( *(c + (i * m + j)) ) ){
	*(c + (i * m + j))  = 0.0;
      }

    }
  }

}

// t(a) -> b
// a = n x m -> b = m x n
// a and b must be compalete different matrix
void matrix_transpose(const double *a, double *b, const int n, const int m){
  int i,j; i = j = 0;

  for (i = 0; i < n; i++){ //row
    for (j = 0; j < m; j++){ //col
      *(b + (j * n + i)) = *(a + (i * m + j));
    }
  }

}

//-------------------------------------------
// C <- t(A) %*% B
// c = retuls, a, b = two matrices
// a = m x l
// b = m x n
// c = t(a) x b
//  c = (l x m) x (m x n) -> l x n
//-------------------------------------------
void matrix_left_transpose_x(double *c, const double *a, const double *b, const int l, const int m, const int n){
	double *t = new double[l * m];

	matrix_init_zero(t, l, m);
	matrix_transpose(a, t, l, m); //t(a) -> t ????
	//matrix_transpose(a, t, m, l); //t(a) -> t [ l x m ]
	matrix_x(c, t, b, l, m, n);

	delete[] t;
	t = NULL;
}

// C <- A %*% t(B)
//  a = l x m
//  b = n x m
void matrix_right_transpose_x(double *c, const double *a, const double *b, const int l, const int m, const int n){
  //double *t = new double[n * m];
  /*
  matrix_init_zero(t, n, m);
  matrix_transpose(b, t, n, m);
  matrix_x(c, a, t, l, m, n);
  */

  double *t = new double[m * n];
  matrix_init_zero(t, m, n);
  matrix_transpose(b, t, n, m); // t(b) -> t [ m x n]
  matrix_x(c, a, t, l, m, n); // l,m * m,n -> l,n

  delete[] t;
  t = NULL;
}

// a = m x l -> l x m
// b = m x n
// c = l x n
// ... (l, m, n) <- result of transcpose of a
void matrix_tx_left(double *c, const double *a, const double *b, const int l, const int m, const int n){
  double t = 0;
  for (int i = 0; i < l; i++){
    for (int j = 0; j < n; j++){

      t = 0.0;
      for (int k = 0; k < m; k++){
	t += *(a + (k * l + i)) * *(b + (k * n + j));
      }
      *(c + (i * n + j)) = t;

    }
  }
}

// a = l x m,  b= n x m, c= l x n
void matrix_tx_right(double *c, const double *a, const double *b, const int l, const int m, const int n){
  double t = 0;
  for (int i = 0; i < l; i++){
    for (int j = 0; j < n; j++){
      for (int k = 0; k < m; k++){
	t += *(a + (i * m + k)) * *(b + (j * m + k));
      }
      *(c + (i * n + j)) = t;
      t = 0;
    }
  }
}


void factorize(int row,  double *v1, int col1,  int ranks, unsigned int count, MatrixFactor *mf){
  double cost;
  
  // W: weight matrix
  // H: feature matrix
  double *h1 = new double[ranks * col1];
  double *hn1 = new double[ranks * col1];
  double *hd1 = new double[ranks * col1];
  double *hd_t = new double[ranks * ranks];
  
  double *w = new double[row * ranks];
  double *wn1  = new double[row * ranks];
  double *wd1 = new double[row * ranks];
  double *wd_t1 = new double[row * col1];
  
  double *wh1 = new double[row * col1]; // -> V1

  
  matrix_init(w, row, ranks);    //row x feature
  matrix_init(h1, ranks, col1);  //feature x col1
  
  matrix_init_zero((double*)wh1, row, col1); //-> V1
  
  matrix_init_zero(hd_t, ranks, ranks); // t(W) x (W) -> (f,r) x (r,f) = (f,f)
  
  matrix_init_zero(hn1, ranks, col1); // t(W) x V1 = (f,r) x (r,c) -> (f,c)
  matrix_init_zero(hd1, ranks, col1); // t(W)W x H = (f,f) x (f,c) -> (f, c)
  
  matrix_init_zero(wn1, row, ranks); // V1 x t(H1) => (r,c) x (c,f) -> (r,f)
  matrix_init_zero(wd_t1, row, col1);    // W x H1 -> (r,f) x (f,c) -> (r,c)
  matrix_init_zero(wd1, row, ranks); // (r,c) x t(H1) => (r,c) x (c,f) -> (r,f)
  
  unsigned int i = 0;
  for (i = 0; i < count; i++){
    
    // W = row x feature
    // H1 = f x c1
    // H2 = f x c2
    // WH1 = r x c1
    // WH2 = r x c2
    
    //HD_T  = t(W)W -> f x f
    //HN1  =  t(W) x V1 -> f x c
    //HD1  = t(W)W x H1 -> f x c
    
    //WN1   = V1 x t(H1) -> r x f
    //WD_T  = W x H1 -> r x c
    //WD      = WxH1 x t(H1) -> r, f
    matrix_x(wh1, w, h1, row, ranks, col1); // WH1 -> r x c1
    
    cost = matrix_diff(v1, wh1, row, col1); //scalar

    if(std::isnan(cost)){
      printf("COST was nan !!!\n");
      exit(1);
    }

    if (cost < ZERO){ break; }
    
    //====================
    // Update Feature Matrix H
    //====================
    //function (l,m,n)
    //w = m x l -> t(W) lxm, v1 = m x n, hn1 = l x n
    matrix_tx_left(hn1, w, v1, ranks, row, col1); //t(W)V1 -> HN1
    matrix_tx_left(hd_t, w, w, ranks, row, ranks); //t(W)W -> HD_t [f,f]
    
    matrix_x(hd1, hd_t, h1, ranks, ranks, col1); //t(W)W %x% H1 -> [f,f] [f,c] -> f,c
    
    // H1 <- H1 x t(W)V1, H2 <- H2 x t(W)V2
    matrix_x(h1, h1, hn1, ranks, col1); // H1 x HN1 -> [f,c] x [f,c1] 
    
    //Update H1(n+1) <-  H1t(W)V1 / t(W)WH1
    matrix_divide(h1, h1, hd1, ranks, col1); // h1 [ f, c]
    
    //-------------------------------------------------------------------------------------------
    // Update Weight Matrix W
    //-------------------------------------------------------------------------------------------
    
    //WN1   = V1 x t(H1) -> r x f
    //WD_T  = W x H1 -> r x c
    //WD      = WxH1 x t(H1) -> r, f
    matrix_tx_right(wn1, v1, h1, row, col1, ranks); // V1%*% t(H1) -> WN1 [ r, f]
    matrix_x( wd_t1, w, h1, row, ranks, col1);              // W %*% H1 -> WD_T [r, c1]
    matrix_tx_right( wd1, wd_t1, h1, row, col1, ranks); // WH1 %*% t(H1) -> WD1 [r, f]
    
    matrix_x(w, w, wn1, row, ranks);         // W * WN1 -> W [r,f]
    matrix_divide(w, w, wd1, row, ranks); // W / WD1 -> W [r,f]
  }

  matrix_x(wh1, w, h1, row, ranks, col1); // WH1 -> r x c1
  cost = matrix_diff(v1, wh1, row, col1); //scalar

  // this is a result of single run
  mf->h1 = h1;
  mf->w    = w;
  mf->wh1 = wh1;
  mf->diff  = cost;

  delete[] hn1;
  delete[] hd1;
  delete[] hd_t;
  delete[] wn1;
  delete[] wd1;
  delete[] wd_t1;
}



//B is a target matrix row x col
//A is a vector in ROW length
void consensus_maxCol(double* a, const double* b, int row, int col){
  int i,j, max_j;
  double max_v;

  for (i = 0; i < row; i++){ //row
    max_j  = -1; max_v = -1.0;
    
    //search maximum
    for (j = 0; j < col; j++){ //col
      if(max_v < *(b + (i * col + j)) ){
	max_j = j;
	max_v = *(b + (i * col + j));
      }
    }
    *(a + i ) = max_j + 1;
  }

}

//B is a target matrix row x col
//A is a vector in COL length
void consensus_maxRow(double* a, const double* b, int row, int col){
  int i,j, max_i;
  double max_v;
  
  for (j = 0; j < col; j++){ //col

    max_i  = -1;  max_v = -1.0;

    //search maximum row in each col
    for (i = 0; i < row; i++){ //row
    
      if(max_v < *(b + (i * col + j)) ){
	max_i  = i; 
	max_v = *(b + (i * col + j));
      }
    }

    *(a + j ) = max_i + 1;
  }

}

// the matrix is square matrix
void Update_ConsM(double* Cons, double* M, int row, int col, int mode){
  
  double *vectMax, *tempCons, *tempCons_t;
  int size;

  if(mode == 1){
    //this is "maximum value in a size for each col"
    //use this one for W matrix
    vectMax    = new double [ row ];
    tempCons   = new double [ row * row];
    tempCons_t = new double [ row * row];
    consensus_maxCol( vectMax, M,   row, col);
    size = row;
  }
  if(mode == 2){
    //this is "maximum value in a col for each size"
    //use this one for H matrix
    vectMax    = new double [ col ];
    tempCons   = new double [ col * col];
    tempCons_t = new double [ col * col];
    consensus_maxRow( vectMax, M, row, col);
    size = col;
  }

  //make square matrix
  for(int i = 0; i<size; i++){
    memcpy(  (tempCons + (i * size ) ), vectMax, size * sizeof(double) );
  }
  //transpose matrix
  matrix_transpose( tempCons, tempCons_t, size, size);
  //subtract
  // values > 0 means i , j was in same cluster
  matrix_subtract_abs_bool(tempCons, tempCons, tempCons_t, size, size, 1);
  //count up
  matrix_add(Cons, Cons, tempCons, size, size);

  delete tempCons;
  delete tempCons_t;
  delete vectMax;
  
}


void joint_factorize(int row,
		     double *v1, int col1,
		     double *v2, int col2,
		     int ranks, unsigned int count,
		     MatrixFactor *mf,
		     double *ConsCell, double *ConsGE, double *ConsCT
		     ){
  double cost, cost1, cost2;
  
  // W: weight matrix
  // H: feature matrix
  double *h1 = new double[ranks * col1];
  double *h2 = new double[ranks * col2];

  double *hn1 = new double[ranks * col1];
  double *hn2 = new double[ranks * col2];
  double *hd1 = new double[ranks * col1];
  double *hd2 = new double[ranks * col2];
  double *hd_t = new double[ranks * ranks];

  double *w = new double[row * ranks];
  double *wn1  = new double[row * ranks];
  double *wn2  = new double[row * ranks];
  double *wd1 = new double[row * ranks];
  double *wd2 = new double[row * ranks];
  double *wd_t1 = new double[row * col1];
  double *wd_t2 = new double[row * col2];

  double *wh1 = new double[row * col1]; // -> V1
  double *wh2 = new double[row * col2]; // -> V2

  matrix_init(w, row, ranks);    //row x feature
  matrix_init(h1, ranks, col1);  //feature x col1
  matrix_init(h2, ranks, col2);  //feature x col2

  matrix_init_zero((double*)wh1, row, col1); //-> V1
  matrix_init_zero((double*)wh2, row, col2); //-> V2

  matrix_init_zero(hd_t, ranks, ranks); // t(W) x (W) -> (f,r) x (r,f) = (f,f)

  matrix_init_zero(hn1, ranks, col1); // t(W) x V1 = (f,r) x (r,c) -> (f,c)
  matrix_init_zero(hd1, ranks, col1); // t(W)W x H = (f,f) x (f,c) -> (f, c)
  matrix_init_zero(hn2, ranks, col2);
  matrix_init_zero(hd2, ranks, col2);
  
  matrix_init_zero(wn1, row, ranks); // V1 x t(H1) => (r,c) x (c,f) -> (r,f)
  matrix_init_zero(wd_t1, row, col1);    // W x H1 -> (r,f) x (f,c) -> (r,c)
  matrix_init_zero(wd1, row, ranks); // (r,c) x t(H1) => (r,c) x (c,f) -> (r,f)

  matrix_init_zero(wn2, row, ranks);
  matrix_init_zero(wd2, row, ranks);
  matrix_init_zero(wd_t2, row, col2);


  unsigned int i = 0;
  for (i = 0; i < count; i++){

    // W = row x feature
    // H1 = f x c1
    // H2 = f x c2
    // WH1 = r x c1
    // WH2 = r x c2

    //HD_T  = t(W)W -> f x f
    //HN1  =  t(W) x V1 -> f x c
    //HD1  = t(W)W x H1 -> f x c
    
    //WN1   = V1 x t(H1) -> r x f
    //WD_T  = W x H1 -> r x c
    //WD      = WxH1 x t(H1) -> r, f

    /* this is waste of time */
    /*
    matrix_oneNorm_col(w, row, features);
    matrix_oneNorm_col(h1, features, col1);
    matrix_oneNorm_col(h2, features, col2);
    */

    matrix_x(wh1, w, h1, row, ranks, col1); // WH1 -> r x c1
    matrix_x(wh2, w, h2, row, ranks, col2); // WH2 -> r x c2

    cost1 = matrix_diff(v1, wh1, row, col1); //scalar
    cost2 = matrix_diff(v2, wh2, row, col2); //scalar
    cost   = cost1 + cost2;
    
    if( std::isnan(cost) ){
      printf("COST was nan !!!\n");
      exit(1);
    }

    if (cost < ZERO){ break; }

    //====================
    // Update Feature Matrix H
    //====================
    //function (l,m,n)
    //w = m x l -> t(W) lxm, v1 = m x n, hn1 = l x n
    matrix_tx_left(hn1, w, v1, ranks, row, col1); //t(W)V1 -> HN1
    matrix_tx_left(hn2, w, v2, ranks, row, col2);
    matrix_tx_left(hd_t, w, w, ranks, row, ranks); //t(W)W -> HD_t [f,f]

    matrix_x(hd1, hd_t, h1, ranks, ranks, col1); //t(W)W %x% H1 -> [f,f] [f,c] -> f,c
    matrix_x(hd2, hd_t, h2, ranks, ranks, col2); //t(W)W %x% H2 -> 

    // H1 <- H1 x t(W)V1, H2 <- H2 x t(W)V2
    matrix_x(h1, h1, hn1, ranks, col1); // H1 x HN1 -> [f,c] x [f,c1] 
    matrix_x(h2, h2, hn2, ranks, col2); // H2 x HN2 -> [f,c] x [f ,c2]

    //Update H1(n+1) <-  H1t(W)V1 / t(W)WH1
    matrix_divide(h1, h1, hd1, ranks, col1); // h1 [ f, c]
    matrix_divide(h2, h2, hd2, ranks, col2); // h2 [ f, c]

    //-------------------------------------------------------------------------------------------
    // Update Weight Matrix W
    //-------------------------------------------------------------------------------------------
    
    //WN1   = V1 x t(H1) -> r x f
    //WD_T  = W x H1 -> r x c
    //WD      = WxH1 x t(H1) -> r, f
    matrix_tx_right(wn1, v1, h1, row, col1, ranks); // V1%*% t(H1) -> WN1 [ r, f]
    matrix_tx_right(wn2, v2, h2, row, col2, ranks);
    matrix_add(wn1, wn1, wn2, row, ranks); // WN1 -> WN1 + WN2
	  
    matrix_x( wd_t1, w, h1, row, ranks, col1);              // W %*% H1 -> WD_T [r, c1]
    matrix_x( wd_t2, w, h2, row, ranks, col2);

    matrix_tx_right( wd1, wd_t1, h1, row, col1, ranks); // WH1 %*% t(H1) -> WD1 [r, f]
    matrix_tx_right( wd2, wd_t2, h2, row, col2, ranks);

    matrix_add(wd1, wd1, wd2, row, ranks); // WD1 -> WD1 + WD2

    matrix_x(w, w, wn1, row, ranks);         // W * WN1 -> W [r,f]
    matrix_divide(w, w, wd1, row, ranks); // W / WD1 -> W [r,f]

    /*    
    Update_ConsM(ConsCell, w,  row, features, 1); //1: max in each row for Cell, 2: max in each col for H matirx
    Update_ConsM(ConsGE,   h1, features, col1, 2); //1: max in each row for Cell, 2: max in each col for H matirx
    Update_ConsM(ConsCT,   h2, features, col2, 2); //1: max in each row for Cell, 2: max in each col for H matirx
    */
  }

  Update_ConsM(ConsCell, w,  row, ranks, 1); //1: max in each row for Cell, 2: max in each col for H matirx
  Update_ConsM(ConsGE,   h1, ranks, col1, 2); //1: max in each row for Cell, 2: max in each col for H matirx
  Update_ConsM(ConsCT,   h2, ranks, col2, 2); //1: max in each row for Cell, 2: max in each col for H matirx

  matrix_x(wh1, w, h1, row, ranks, col1); // WH1 -> r x c1
  matrix_x(wh2, w, h2, row, ranks, col2); // WH2 -> r x c2

  cost1 = matrix_diff(v1, wh1, row, col1); //scalar
  cost2 = matrix_diff(v2, wh2, row, col2); //scalar
  cost   = cost1 + cost2;

  // this is a result of single run
  mf->h1 = h1;
  mf->h2 = h2;
  mf->w   = w;
  mf->wh1 = wh1;
  mf->wh2 = wh2;
  mf->diff  = cost;

  delete[] hn1;    delete[] hn2;
  delete[] hd1;    delete[] hd2;
  delete[] hd_t;
  delete[] wn1;    delete[] wn2;
  delete[] wd1;    delete[] wd2;
  delete[] wd_t1;  delete[] wd_t2;
}


//std::vector<std::string> *items, 
std::vector<std::string> FiletoMatrix(  std::string *file_name,   int *row, int *col){
  std::string lbuf, buf;
  std::ifstream file( file_name->c_str() );

  std::vector<std::string> items;
  
  *row = 0;
  while ( getline(file, lbuf) ){
    if( lbuf.length() == 0 ){ continue; }
    if( lbuf[0] == '#' ){ continue; }

    std::istringstream iss( lbuf );
    *row += 1;
    //std::cout << lbuf << std::endl;
    while( getline(iss, buf, '\t') ){
      items.push_back(buf);
    }
  }
  *col = (int)items.size() / *row;

  return items;
}


int getParam(int argc, char* argv[], Parameter* param, int howmany){
  int option,  cnt;
  char usage[] = "USAGE: %>nmf -r [runs] -l [loops] -k [ranks] -t [Consensus Threshold (0.0-1.0)] -p [output -g matrix (0|1)] -g [Gene Expression Profile] -c [Contami Profile]";

  cnt = 0;
  while( (option = getopt(argc, argv, "r:l:g:t:c:k:p:")) != -1){

    switch(option){
    case 'g' :
      if(optarg)    strcpy(param->gefile, optarg);
      cnt++; break;

    case 'c' :
      if(optarg)      strcpy(param->ctfile,  optarg);
      cnt++; break;

    case 'r' : 
      if(optarg) param->howmany_runs = std::atoi(optarg);
      cnt++; break;

    case 'k' : 
      if(optarg) param->ranks = std::atoi(optarg);
      cnt++; break;
      
    case 'l' : if(optarg) param->howmany_loop = std::atoi(optarg);
      cnt++; break; 

    case 't' : 
      if(optarg) param->Cons_Thres = std::atof(optarg);
      cnt++; break;

    case 'p' : 
      if(optarg) param->write_gene = std::atof(optarg);
      cnt++; break;

      //case '?' : fprintf(fp,"Unknown option '%c'\n", optopt); cnt++;break;
    }
  }

  /*
  printf("%d\n", param->howmany_runs);
  printf("%d\n", param->howmany_loop);
  printf("%s\n", param->gefile);
  printf("%s\n", param->ctfile);
  */

  if(cnt != howmany){
    printf("Joint NMF for OpenContami (version %.1f)\n", VER);
    printf("%s\n", usage);
    return FALSE;
  }

  return TRUE;
}


void MatrixtoFile( std::string *file_name, double *m, int row, int col, std::string *message){
  int i, j;

  std::ofstream file( file_name->c_str() );
  file.precision(4);

  file << "# " << std::flush;
  file << message->c_str() << std::endl;

  //if(!diag){
    for(i = 0; i<row; i++){
      for(j = 0; j<col; j++){
	
	file << std::fixed << *(m + (i * col + j)) << std::flush;
	if(j < (col-1)){
	  file << "\t" << std::flush;
	}
      }
      file << std::endl;
    }
    /*
  }else{

    for(i = 0; i<row; i++){
      for(j = 0; j<i+1; j++){
	
	file << std::fixed << *(m + (i * col + j)) << std::flush;
	if( j < i){
	  file << "\t" << std::flush;
	}
      }
      file << std::endl;
    }
    
  }
    */

  file.close();
}



