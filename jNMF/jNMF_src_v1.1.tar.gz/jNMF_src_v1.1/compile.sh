
if [ -e jnmf ]; then 
 mv ./jnmf ./jnmf_old
fi

## -std=c++11 is for using std:stod
g++ jnmf.cpp -o jnmf -std=c++11

## help
if [ -e jnmf ]; then
  chmod 755 ./jnmf
  ./jnmf
fi

## testing
if [ ! -e TEST ]; then
  mkdir TEST
fi

cd TEST
../jnmf -r 5 -l 10000 -k 3 -t 0.8 -p 1 -g ../TOY/X1.txt -c ../TOY/X2.txt

