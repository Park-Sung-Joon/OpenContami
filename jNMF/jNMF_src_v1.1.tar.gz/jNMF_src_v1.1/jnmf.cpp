#include "park_jnmf.h"

// Coded by S.J. Park (from 2018.03.10 - )
// Copyright CC by XX

int main(int argc, char* argv[]){
  int i, j, cnt, FEATURES;
  std::string message;
  std::string file_name;
  std::vector<std::string> items;
  struct stat st;

  int DEBUG = 1;

  Parameter Param;
  if( getParam(argc, argv, &Param, 7) == FALSE ){
    exit(2);
  }

  //Get Gene Expression Matrix
  int ROW1, COL1;
  file_name = Param.gefile;
  if( stat(Param.gefile, &st)){
    printf("Input file '-g %s' was not found\n", Param.gefile);
    exit(1);
  }
  items = FiletoMatrix( &file_name, &ROW1, &COL1);
 
  double *GE = (double*)malloc(sizeof(double) * (ROW1*COL1) );
  for(i = 0; i<ROW1; i++){
    for(j = 0; j<COL1; j++){
      *(GE + (i * COL1 + j) ) = std::stod( items[ i * COL1 + j ] );
    }
  }
  items.clear();


  printf("GE matrix\t");
  printf("%s\n", Param.gefile);
  printf("ROW %d COL %d\n", ROW1, COL1);
  if(DEBUG){
    //matrix_print(GE, ROW1, COL1);
  }


  //Get Contami Expression Matrix
  int ROW2, COL2;
  file_name = Param.ctfile;
  if( stat(Param.ctfile, &st)){
    printf("Input file '-c %s' was not found\n", Param.ctfile);
    exit(1);
  }

  items = FiletoMatrix( &file_name, &ROW2, &COL2);
  double *CT = (double*)malloc(sizeof(double) * (ROW2*COL2) );
  for(i = 0; i<ROW2; i++){
    for(j = 0; j<COL2; j++){
      *(CT + (i * COL2 + j) ) = std::stod(items[ i * COL2 + j ]);
    }
  }
  items.clear();

  printf("CT matrix\t");
  printf("%s\n", Param.ctfile);
  printf("ROW %d COL %d\n", ROW2, COL2);
  if(DEBUG){
    //matrix_print(CT, ROW2, COL2);
  }

  //srand((unsigned)time(NULL));
  //srand(1234);
  init_genrand( (unsigned)time(NULL) );

  //ROW1 and ROW2 must be equal
  FEATURES = Param.ranks;
  
  //Error check
  if(ROW1 != ROW2){
    printf("Matrix dimension of -g was %d x %d\n", ROW1, COL1);
    printf("Matrix dimension of -c was %d x %d\n", ROW2, COL2);
    printf("Aborted\n");
    return 1;
  }
  if(FEATURES < 2){
    printf("Number of ranks -r was %d\n", FEATURES);
    printf("Aborted\n");
    return 1;
  }

  // Keep connectivity map
  // GE <- from H1 cols, CT<- from H2 cols
  double *ConsCell, *ConsGE, *ConsCT;
  ConsCell = new double [ ROW1 * ROW1];
  ConsGE   = new double [ COL1 * COL1];
  ConsCT   = new double [ COL2 * COL2];
  matrix_init_zero(ConsCell, ROW1, ROW1);
  matrix_init_zero(ConsGE,   COL1, COL1);
  matrix_init_zero(ConsCT,   COL2, COL2);


  MatrixFactor bestMF;
  bestMF.w  = new double [ ROW1     * FEATURES];
  bestMF.h1 = new double [ FEATURES * COL1];
  bestMF.h2 = new double [ FEATURES * COL2];
  
  matrix_init_zero(bestMF.w,  ROW1,     FEATURES);
  matrix_init_zero(bestMF.h1, FEATURES, COL1);
  matrix_init_zero(bestMF.h2, FEATURES, COL2);
  bestMF.diff = 0.0;


  /* for finding maximum */
  MatrixFactor* pMF;

  //find most minimal residual model
  int update = 0;
  for(cnt=0; cnt<Param.howmany_runs; cnt++){
    update = 0;

    /* CORE */
    pMF = new MatrixFactor;
    joint_factorize(  ROW1, GE, COL1, CT, COL2, FEATURES,
		      Param.howmany_loop, pMF,
		      ConsCell, ConsGE, ConsCT);
    
    if(cnt == 0){ update = 1;  }else{
      if(pMF->diff < bestMF.diff){ update = 1;  }
    }

    if(update){
      // copy pMF -> bestMF
      matrix_copy(bestMF.w,  pMF->w,  ROW1, FEATURES);
      matrix_copy(bestMF.h1, pMF->h1, FEATURES, COL1);
      matrix_copy(bestMF.h2, pMF->h2, FEATURES, COL2);
      bestMF.diff  = pMF->diff;
    }

    if(DEBUG){
      printf("[%4d / %4d] DIFF= %f %f\n", cnt+1, Param.howmany_runs, bestMF.diff, pMF->diff);
      //printf("Coef H1 matrix\n");
      //matrix_print(pMF->h1, FEATURES, COL1,  FALSE);
    }
    delete pMF;
    // STOP the loop
    if( !stat(STOP_FILE, &st)){
      //update cnt
      printf("STOP jNMF process\n");
      Param.howmany_runs = cnt + 1;
      break;
    }
    /*
    std::ifstream ifs( STOP_FILE );
    if(  ifs ){
      //update cnt
      printf("STOP jNMF process\n");
      Param.howmany_runs = cnt + 1;
      break;
    }
    */

  }

  //Average for Connectivity Matrix
  /*
  matrix_divide_scalar(ConsCell, ConsCell, Param.howmany_runs*Param.howmany_loop, ROW1, ROW1);
  matrix_divide_scalar(ConsGE, ConsGE, Param.howmany_runs*Param.howmany_loop, COL1, COL1);
  matrix_divide_scalar(ConsCT, ConsCT, Param.howmany_runs*Param.howmany_loop, COL2, COL2);
  */

  matrix_divide_scalar(ConsCell, ConsCell, Param.howmany_runs, ROW1, ROW1);
  matrix_divide_scalar(ConsGE, ConsGE,     Param.howmany_runs, COL1, COL1);
  matrix_divide_scalar(ConsCT, ConsCT,     Param.howmany_runs, COL2, COL2);

  //Normalize (0 to 1.0)
  matrix_oneNorm_col(bestMF.w, ROW1, FEATURES);
  matrix_oneNorm_col(bestMF.h1, FEATURES, COL1);
  matrix_oneNorm_col(bestMF.h2, FEATURES, COL2);

  // Processing Result
  int maxC_i; double maxC_v;

  // this marix converts W to FtoCell with binary value (-1,1), but col order is the sorted Features
  double *FtoCell    = new double [ ROW1 * FEATURES]();
  double *FtoGene    = new double [ COL1 * FEATURES ]();
  double *FtoMicrobe = new double [ COL2 * FEATURES ]();
  int this_feature, this_cell;
  int this_gene;
  int this_microbe;

  std::vector<std::pair<int, double> > Fv(FEATURES) ; //F index, F max weight
  std::vector<int> maxCell_ID(FEATURES);

  //=============== Mapping F -> Cell =============//
  //STEP 1: In the marix W, search maximal F for a cell.
  //            Even if there exists tie cells, never care about them (because STEP 2)
  for(j = 0; j <FEATURES; j++){
    maxC_i = -1; maxC_v = -1.0;

    for(i=0 ;i< ROW1; i++){                        //each Cell (row)
      *(FtoCell + (i * FEATURES + j  ) ) = -1;  //initialize

      if( *(bestMF.w + (i*FEATURES + j )) > maxC_v ){ //update
	maxC_i = i;
	maxC_v = *(bestMF.w + (i*FEATURES + j ));
      }
    }

    Fv[ j ] = std::make_pair( j, maxC_v);      //original Feature id and value
    maxCell_ID[j] = maxC_i; //keep this cell ID
  } //next Feature
  //sort in decreasing order of F weight
  //Now, Fv[j] j=1,2,3 ->> pair( 4,2,1...). 4,2,1 is the original index
  //So, maxCell_ID[  Fv[0].first ] is the cell ID for this original F index

  std::sort( Fv.begin(), Fv.end(),
	     [](const pair<int, double>& lv, const pair<int, double>& rv) { return lv.second > rv.second; }
	     );


  // End of STEP 1;

  // STEP 2: Loo at ConsCell for grouping well-co-clustered Cells 
  for(i=0; i< FEATURES;  i++){
    this_feature = Fv[i].first;
    this_cell    = maxCell_ID[ this_feature ];  //Cell index found in STEP 1
 
    //std::vector<int> work_vec;
    std::vector<std::pair<int, double> > work_vec;
    //get cell cluster from ConsCell (rxr)
    for(j=0; j<ROW1; j++){
      if(  *(ConsCell + ( this_cell * ROW1 + j) ) >= Param.Cons_Thres ){
	//work_vec.push_back(j); //keep it up
	work_vec.push_back( std::make_pair( j, *(ConsCell + ( this_cell * ROW1 + j)) ) );
      }
    }
    //sort in incrasing order of Cell IDs
    //std::sort(work_vec.begin(), work_vec.end() );
    //remove redundant IDs in this cell cluster
    //work_vec.erase( std::unique( work_vec.begin(), work_vec.end()),  work_vec.end() );
    //use flag 1 for thes cell IDs found
    for(j = 0; j < work_vec.size(); j++){
      //*(FtoCell + ( work_vec[j] * FEATURES + this_feature) ) = 1; //DO not like this
      //NOTE: Now, col index from left to right in FtoCell is the sorted order of Fv
      //*(FtoCell + ( work_vec[j] * FEATURES + i) ) = 1; //DO like this (so from left to right, ordered F id)
      *(FtoCell + ( work_vec[j].first * FEATURES + i) ) = work_vec[j].second; //DO like this (so from left to right, ordered F id

    }
  }
  //========== End of Mapping Fs -> Cells ==============//


  //============= Mapping Fs -> Genes ==============//
  // STEP 3: search maximum genes in H1 (feature x col1)
  for(i = 0; i <FEATURES; i++){ 
    this_feature = Fv[i].first; //sorted original index of Fs

    maxC_i = -1; maxC_v = -1.0;
    for(j = 0 ;j < COL1; j++){                //each Gens (col)
      *(FtoGene + (j * FEATURES + i ) ) = -1;  //initialize
      
      if( *(bestMF.h1 + ( this_feature*COL1 + j )) > maxC_v ){
	maxC_i = j;
	maxC_v = *(bestMF.h1 + (this_feature*COL1 + j ));
      }
    }

    // STEP 4: get cell cluster from ConsCell (col1 x col1)
    this_gene = maxC_i;
    //std::vector<int> work_vec;
    std::vector<std::pair<int, double> > work_vec;

    for(j=0;  j<COL1;  j++){
      if(  *(ConsGE + ( this_gene * COL1 + j) ) >= Param.Cons_Thres ){
	//work_vec.push_back(j);
	work_vec.push_back( std::make_pair( j, *(ConsGE + ( this_gene * COL1 + j)) ) );
      }
    } // end of this cell

    //sort in incrasing order of IDs
    //std::sort(work_vec.begin(), work_vec.end() );
    //remove redundant IDs
    //work_vec.erase( std::unique( work_vec.begin(), work_vec.end()),  work_vec.end() );
    for(j = 0; j < work_vec.size(); j++){
      //Becareful about row x col, 
      //*(FtoGene + ( work_vec[j] * FEATURES + i ) ) = 1;
      *(FtoGene + ( work_vec[j].first * FEATURES + i ) ) = work_vec[j].second;
    }
  } //next Feature

  //============= Mapping Fs -> Microbes ==============//
  //STEP 5: 
  for(i = 0; i <FEATURES; i++){
    this_feature = Fv[i].first; //sorted original index of Fs

    maxC_i = -1; maxC_v = -1.0;
    for(j = 0 ;j < COL2; j++){                //each Gens (col)
      *(FtoMicrobe + (j * FEATURES + i ) ) = -1;  //initialize
      
      //How to deal with equal value -> see ConsGene matrix
      if( *(bestMF.h2 + ( this_feature*COL2 + j )) > maxC_v ){
	maxC_i = j;
	maxC_v = *(bestMF.h2 + (this_feature*COL2 + j ));
      }
    }

    this_microbe = maxC_i;
    //std::vector<int> work_vec;
    std::vector<std::pair<int, double> > work_vec;
    for(j=0;  j<COL2;  j++){
      if(  *(ConsCT + ( this_microbe * COL2 + j) ) >= Param.Cons_Thres ){
	//work_vec.push_back(j);
	work_vec.push_back( std::make_pair( j, *(ConsCT + ( this_microbe * COL2 + j)) ) );
      }
    } // end of this cell

    //sort in incrasing order of Cell ID
    //std::sort(work_vec.begin(), work_vec.end() );
    //remove redundant IDs in this cell cluster
    //work_vec.erase( std::unique( work_vec.begin(), work_vec.end()),  work_vec.end() );
    //stock thes cell IDs to FtoCell[ this_feature][0], [][1], [][2],...
    for(j = 0; j < work_vec.size(); j++){
      //*(FtoMicrobe + ( work_vec[j]  * FEATURES + i)) = 1;
      *(FtoMicrobe + ( work_vec[j].first * FEATURES + i) ) = work_vec[j].second;
    }
  } //next Feature
  //============== End of Mapping Microbes =============//


  file_name = "Module_jnmf.txt";
  std::ofstream file( file_name.c_str() );

  file << "# ";
  for(i=0;i<argc;i++){
    file << argv[i] << " ";
  }
  file << std::endl;

  file << "# Matrix dimension of -g was " << ROW1 << " x " << COL1 << endl;
  file << "# Matrix dimension of -c was " << ROW2 << " x " << COL2 << endl;

  for(j=0; j < FEATURES;  j++){ //Already sorted
    file << "# [Module ID: " << j+1 << " ] K" << Fv[j].first+1 << "\t" << std::fixed << std::setprecision(4) << Fv[j].second << endl;
  }

  file << "#TYPE"  << "\t";
  file << "ID"     << "\t";
  file << "Module" << "\t";
  file << "Connect" << "\t";
  file << "Weight" << endl;
  file.close();


  string type = "Cell";
  matrix_print_module(Fv, FtoCell, ROW1, FEATURES, &type, &file_name, bestMF.w, 1); //col

  type = "Gene";
  matrix_print_module(Fv, FtoGene, COL1, FEATURES, &type, &file_name, bestMF.h1, 2); //row

  type = "Microbe";
  matrix_print_module(Fv, FtoMicrobe, COL2, FEATURES, &type, &file_name, bestMF.h2, 2); //row


  file_name="W_jnmf_best.txt"; 
  std::cout << file_name << std::endl;
  message = "best Weight matirx W";
  MatrixtoFile(&file_name,  bestMF.w, ROW1, FEATURES, &message);

  file_name = "Cell_jnmf_cons.txt";
  std::cout << file_name << std::endl;


  message = "Consensus cluster of Cells in W";
  MatrixtoFile(&file_name,  ConsCell, ROW1, ROW1, &message);

  file_name="Microbe_jnmf_cons.txt";
  std::cout << file_name << std::endl;
  message = "Consensus cluster of Microbes in H2";
  MatrixtoFile(&file_name,  ConsCT, COL2, COL2, &message);

  file_name="H2_jnmf_best.txt";
  std::cout << file_name << std::endl;
  message= "best Coef matirx H2";
  MatrixtoFile(&file_name, bestMF.h2, FEATURES, COL2, &message);


  //this is hard to write down
  //Too slow
  if(Param.write_gene){
    file_name="Gene_jnmf_cons.txt";
    std::cout << file_name << std::endl;
    message = "Consensus cluster of Genes in H1";
    MatrixtoFile(&file_name,  ConsGE, COL1, COL1, &message);

    file_name="H1_jnmf_best.txt"; 
    std::cout << file_name << std::endl;
    message= "best Coef matirx H1";
    MatrixtoFile(&file_name, bestMF.h1, FEATURES, COL1, &message);
  }


  delete GE;
  delete CT;

  delete ConsCell;
  delete ConsGE;
  delete ConsCT;
  
  delete FtoCell;
  delete FtoGene;
  delete FtoMicrobe;

  return 0;
}
